/*
 * Copyright 2016 NXP Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __FSL_PPA_H_
#define __FSL_PPA_H_

#ifdef CONFIG_FSL_LS_PPA
int ppa_init(void);
#endif
#endif
