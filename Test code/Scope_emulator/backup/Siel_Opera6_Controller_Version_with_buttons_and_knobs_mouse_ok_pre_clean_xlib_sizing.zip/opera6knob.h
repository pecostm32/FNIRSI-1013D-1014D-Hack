#ifndef OPERA6KNOB_H
#define OPERA6KNOB_H

#include "xlibfunctions.h"
#include "mousehandling.h"

//Position is given as top left of the bounding box the button is in
//The size of the button is fixed

#define KNOB_TYPE_DOTS              0
#define KNOB_TYPE_DETUNE_COARSE     1
#define KNOB_TYPE_DETUNE_FINE       2
#define KNOB_TYPE_PW                3


typedef struct
{
  tagXlibContext *xc;               //Xlib context for drawing
  MouseRange      mouse;            //Mouse object for this button. Is used for setting the bounding box and to connect the handlers
  int             xpos;             //Un scaled x position
  int             ypos;             //Un scaled y position
  int             type;             //Type of markers around the knob.
  int             capcolor;         //Color of the cap
  int             bodycolor;        //Color of the body
  int             linecolor;        //Color of the lines
  int             indicatorcolor;   //Color of the indicator on the cap
  int             markercolor;      //Color of the markers on the panel
  int             position;         //Position of the indicator on the cap of the knob
} tagOpera6Knob;


void Opera6KnobSetup(tagXlibContext *xc, tagOpera6Knob *knob);
void Opera6KnobDraw(tagOpera6Knob *knob);

void Opera6KnobSetPosition(tagOpera6Knob *knob, int position);
void Opera6KnobDrawPosition(MouseEvent *event, Bool deltacheck);

void Opera6KnobDown(MouseEvent *event);
void Opera6KnobUp(MouseEvent *event);
void Opera6KnobMove(MouseEvent *event);

#endif /* OPERA6KNOB_H */

