//-----------------------------------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------------------------------

#include <stdio.h>
#include <math.h>
#include "opera6knob.h"


#define PI                         3.1415926535897932384
#define PI2                        6.2831853071795864769


#define CalcCoord(c)  BORDER_SIZE + ((c) * xc->scaler)
#define CalcCoordX(x) BORDER_SIZE + ((knob->xpos - (x)) * xc->scaler)
#define CalcCoordY(y) BORDER_SIZE + ((knob->ypos - (y)) * xc->scaler)

void Opera6KnobSetup(tagXlibContext *xc, tagOpera6Knob *knob)
{
  MouseRange  *mouse = &knob->mouse;
  
  //The cap is shifted left and up to create 3D look
  //Calculate bounding box coordinates based on cap of the knob
  int xo = knob->xpos - 6;
  int yo = knob->ypos - 2;
  int l  = xo;
  int r  = xo + 42;
  int t  = yo;
  int b  = yo + 42;

  //Set the radius for the indicator
  double rk = 34.5;
  
  //Scaled size of the indicator dot
  int d = 6 * xc->scaler;
  
  //Variables for marker position calculation
  double a;
  double s;
  double c;
  
  //Variables for positions
  int x1;
  int y1;
  int x2;
  int y2;
  int x3;
  int y3;
  int x4;
  int y4;
  
  //Variable for indexing
  int i;
  
  //For the sharp and square wave symbols
  XSegment lines[4];
  XPoint   points[8];

  knob->xc = xc;
  
  //Fill in the mouserange struct to be able to use the knob via the mouse
  //An extra 5 pixels to allow for selection outside the cap
  mouse->left   = CalcCoord(l) - 5;
  mouse->right  = CalcCoord(r) + 5;
  mouse->top    = CalcCoord(t) - 5;
  mouse->bottom = CalcCoord(b) + 5;
  
  mouse->data = knob;
  mouse->move = NULL;
  mouse->down = Opera6KnobDown;
  mouse->up   = Opera6KnobUp;

  //Set the color of the symbols
  XSetForeground(xc->display, xc->gc, knob->markercolor);

  //Setup for drawing the lines
  XSetLineAttributes(xc->display, xc->gc, 2 * xc->scaler, LineSolid, CapButt, JoinMiter);
  
  //Draw the markers around the knob
  if(knob->type == KNOB_TYPE_PW)
  {
    //The pulse width knob has no dot markers
    //Calculate the position of the 10% pulse wave symbol
    x1 = knob->xpos - 15;
    y1 = knob->ypos + 57;
    x2 = x1 + 10;
    y2 = y1 - 10;
    x3 = x1 + 14;
    
    //Setup the points for drawing the 10% pulse wave symbol
    points[0].x = CalcCoord(x1);
    points[0].y = CalcCoord(y1);
    points[1].x = CalcCoord(x2);
    points[1].y = CalcCoord(y1);
    points[2].x = CalcCoord(x2);
    points[2].y = CalcCoord(y2);
    points[3].x = CalcCoord(x3);
    points[3].y = CalcCoord(y2);
    points[4].x = CalcCoord(x3);
    points[4].y = CalcCoord(y1);
    points[5].x = CalcCoord(x1 + 21);
    points[5].y = CalcCoord(y1);

    XDrawLines(xc->display, xc->win, xc->gc, points, 6, CoordModeOrigin);

    //Calculate the position of the 50% square wave symbol
    x1 = knob->xpos + 7;
    y1 = knob->ypos - 10;
    x2 = x1 + 4;
    y2 = y1 - 10;
    x3 = x1 + 12;
    x4 = x1 + 20;
    
    //Setup the points for drawing the 10% pulse wave symbol
    points[0].x = CalcCoord(x1);
    points[0].y = CalcCoord(y1);
    points[1].x = CalcCoord(x2);
    points[1].y = CalcCoord(y1);
    points[2].x = CalcCoord(x2);
    points[2].y = CalcCoord(y2);
    points[3].x = CalcCoord(x3);
    points[3].y = CalcCoord(y2);
    points[4].x = CalcCoord(x3);
    points[4].y = CalcCoord(y1);
    points[5].x = CalcCoord(x4);
    points[5].y = CalcCoord(y1);
    points[6].x = CalcCoord(x4);
    points[6].y = CalcCoord(y2);
    points[7].x = CalcCoord(x1 + 24);
    points[7].y = CalcCoord(y2);

    XDrawLines(xc->display, xc->win, xc->gc, points, 8, CoordModeOrigin);

    //Calculate the position of the 90% pulse wave symbol
    x1 = knob->xpos + 30;
    y1 = knob->ypos + 47;
    y2 = y1 + 10;
    x2 = x1 + 10;
    x3 = x1 + 14;
    
    //Setup the points for drawing the 90% pulse wave symbol
    points[0].x = CalcCoord(x1);
    points[0].y = CalcCoord(y1);
    points[1].x = CalcCoord(x2);
    points[1].y = CalcCoord(y1);
    points[2].x = CalcCoord(x2);
    points[2].y = CalcCoord(y2);
    points[3].x = CalcCoord(x3);
    points[3].y = CalcCoord(y2);
    points[4].x = CalcCoord(x3);
    points[4].y = CalcCoord(y1);
    points[5].x = CalcCoord(x1 + 21);
    points[5].y = CalcCoord(y1);

    XDrawLines(xc->display, xc->win, xc->gc, points, 6, CoordModeOrigin);
  }
  else
  {
    //For the other types the dots around the knob are default
    //Calculate center position of the body
    x1 = knob->xpos + 21;
    y1 = knob->ypos + 21;
    
    //Do the 11 dots
    for(i=0;i<11;i++)
    {
      a = (360.0 - (((i * 30.0) + 30.0) / 180.0)) * PI;
      s = sin(a);
      c = cos(a);

      //Calculate the position of this dot
      x2 = x1 + (rk * s) - 3;
      y2 = y1 + (rk * c) - 3;
      
      //Scale to actual screen coordinates
      x2 = CalcCoord(x2);
      y2 = CalcCoord(y2);
      
      XFillArc(xc->display, xc->win, xc->gc, x2, y2, d, d, Angle0, Angle360);
    }
    
    //For the course detune knob there is a line on the last dot
    if(knob->type == KNOB_TYPE_DETUNE_COARSE)
    {
      //Center of the last dot
      x2 = x1 + (rk * s);
      y2 = y1 + (rk * c);
      
      //End of the line 5 pixels long
      x3 = x1 + ((rk + 7) * s);
      y3 = y1 + ((rk + 7) * c);
      
      //Scale to actual screen coordinates
      x2 = CalcCoord(x2);
      y2 = CalcCoord(y2);
      x3 = CalcCoord(x3);
      y3 = CalcCoord(y3);
      
      //Draw the actual line
      XDrawLine(xc->display, xc->win, xc->gc, x2, y2, x3, y3);
    }
    
    //For detune types the flat symbol needs to be drawn at the first position
    if((knob->type == KNOB_TYPE_DETUNE_COARSE) || (knob->type == KNOB_TYPE_DETUNE_FINE))
    {
      //Calculate the position of the flat
      x2 = knob->xpos - 15;
      y2 = knob->ypos + 45;
      
      //For the back the line is vertically 16 pixels long
      y4 = y2 + 16;

      //Scale to actual screen coordinates
      x3 = CalcCoord(x2);
      y3 = CalcCoord(y2);
      y4 = CalcCoord(y4);
      
      //Draw the back of the flat symbol
      XDrawLine(xc->display, xc->win, xc->gc, x3, y3, x3, y4);

      //The bounding box top left of the belly is halfway the back line
      y3 = y2 + 8;
      y3 = CalcCoord(y3);
      
      //Draw first part of the belly
      XDrawArc(xc->display, xc->win, xc->gc, x3, y3, d, d, Angle270, Angle270);
      
      //Setup for drawing the line from the end of the arc to near the end of the back line
      x4 = x2 + 3;
      y3 = y2 + 14;
      y4 = y2 + 15;
      x4 = CalcCoord(x4);
      y3 = CalcCoord(y3);
      y4 = CalcCoord(y4);

      //Draw the second part of the belly
      XDrawLine(xc->display, xc->win, xc->gc, x3, y4, x4, y3);
    }
 
    //For fine detune the sharp symbol needs to be drawn at the last position
    if(knob->type == KNOB_TYPE_DETUNE_FINE)
    {
      //Calculate the top left position of the sharp
      x2 = knob->xpos + 50;
      y2 = knob->ypos + 52;
      
      x3 = x2 + 12;
      y3 = y2 - 4;
      
      lines[0].x1 = CalcCoord(x2);
      lines[0].y1 = CalcCoord(y2);
      lines[0].x2 = CalcCoord(x3);
      lines[0].y2 = CalcCoord(y3);

      y2 += 4;
      y3  = y2 - 4;
      
      lines[1].x1 = CalcCoord(x2);
      lines[1].y1 = CalcCoord(y2);
      lines[1].x2 = CalcCoord(x3);
      lines[1].y2 = CalcCoord(y3);
      
      x2 += 4;
      y2 -= 10;
      y3  = y2 + 16;
      
      lines[2].x1 = CalcCoord(x2);
      lines[2].y1 = CalcCoord(y2);
      lines[2].x2 = CalcCoord(x2);
      lines[2].y2 = CalcCoord(y3);
      
      x2 += 4;
      y2 -= 2;
      y3 -= 2;
      
      lines[3].x1 = CalcCoord(x2);
      lines[3].y1 = CalcCoord(y2);
      lines[3].x2 = CalcCoord(x2);
      lines[3].y2 = CalcCoord(y3);
    
      XDrawSegments(xc->display, xc->win, xc->gc, lines, 4);
    }
  }

  
  Opera6KnobDraw(knob);
}

void Opera6KnobDraw(tagOpera6Knob *knob)
{
  tagXlibContext *xc = knob->xc;

  //Calculate position shift for the cap
  double xs = 6.0;
  double ys = 2.0;
  
  //Calculate radius of the cap and the indicator
  double r  = 21;
  double r1 = 12.6;
  
  //Calculate the coordinates for drawing the body and the cap
  int x  = CalcCoordX(0);
  int y  = CalcCoordY(0);
  int x1 = CalcCoordX(xs);
  int y1 = CalcCoordY(ys);
  int d  = 42 * xc->scaler;

  //Scaled size of the indicator dot
  int d1 = 6 * xc->scaler;
  
  //Calculate center point of the cap
  int x2 = knob->xpos - xs + r;
  int y2 = knob->ypos - ys + r;

  //Limit the position to a 300 degree range
  if(knob->position < 30)
    knob->position = 30;
  else if(knob->position > 330)
    knob->position = 330;

  //Calculate angle, sin and cosine for the given position
  double a = ((360.0 - knob->position) / 180.0) * PI;
  double s  = sin(a);
  double c  = cos(a);
  
  //Calculate the top left corner coordinates for the indicator for the given position
  x2 += (r1 * s) - 3;
  y2 += (r1 * c) - 3;
  
  //Scale to actual screen coordinates
  x2 = CalcCoord(x2);
  y2 = CalcCoord(y2);
  
  //Draw the body of the knob with a perimeter line
  XSetForeground(xc->display, xc->gc, knob->bodycolor);
  XFillArc(xc->display, xc->win, xc->gc, x, y, d, d, Angle0, Angle360);
  XSetLineAttributes(xc->display, xc->gc, 1, LineSolid, CapButt, JoinMiter);
  XSetForeground(xc->display, xc->gc, knob->linecolor);
  XDrawArc(xc->display, xc->win, xc->gc, x, y, d, d, Angle0, Angle360);

  //Draw the cap of the knob with a perimeter line
  XSetForeground(xc->display, xc->gc, knob->capcolor);
  XFillArc(xc->display, xc->win, xc->gc, x1, y1, d, d, Angle0, Angle360);
  XSetLineAttributes(xc->display, xc->gc, 1, LineSolid, CapButt, JoinMiter);
  XSetForeground(xc->display, xc->gc, knob->linecolor);
  XDrawArc(xc->display, xc->win, xc->gc, x1, y1, d, d, Angle0, Angle360);

  //Draw the indicator on top of the cap
  XSetForeground(xc->display, xc->gc, knob->indicatorcolor);
  XFillArc(xc->display, xc->win, xc->gc, x2, y2, d1, d1, Angle0, Angle360);
}

void Opera6KnobSetPosition(tagOpera6Knob *knob, int position)
{
  //Make sure position stays within the limits
  if(position < 0)
    position = 0;
  else if(position > 255)
    position = 255;
  
  //Convert to knop position
  knob->position = ((position * 300) / 255) + 30;
  
  //Draw the new position
  Opera6KnobDraw(knob);
}

void Opera6KnobDrawPosition(MouseEvent *event, Bool deltacheck)
{
  tagOpera6Knob *knob = event->data;
  XButtonEvent *buttonevent = &event->event->xbutton;
  tagXlibContext *xc = knob->xc;
  
  int degree;
  double rad;
  
  //Calculate position shift for the cap
  double xs = 6.0;
  double ys = 2.0;
  
  //Calculate radius of the cap
  double r  = 21.0;

  //Calculate center point of the cap
  int x = knob->xpos - xs + r;
  int y = knob->ypos - ys + r;

  //Scale to screen coordinates
  x = CalcCoord(x);
  y = CalcCoord(y);
  
  //For x on vertical center line the angle is either 0 or 180 degree
  if(buttonevent->x == x)
  {
    //Below and on the horizontal center line 0 degree
    if(buttonevent->y <= y)
      degree = 180;
    else
      degree = 0;
  }
  //For x left of the vertical center line the range is 1 to 179 degree
  else if(buttonevent->x < x)
  {
    //For y on the horizontal center line the angle is 90 degree
    if(buttonevent->y == y)
      degree = 90;
    else
    {
      //Y below or above the horizontal center line gives 1 to 89 and 91 to 179 degree
      rad = atan((double)(y - buttonevent->y) / (double)(x - buttonevent->x));
      degree = 90 + (rad * (180.0 / PI));
    }
  }
  //For x right of the vertical center line the range is 181 to 359 degree
  else
  {
    //For y on the horizontal center line the angle is 270 degree
    if(buttonevent->y == y)
      degree = 270;
    else
    {
      //Y below or above the horizontal center line gives 181 to 269 and 271 to 359 degree
      rad = atan((double)(buttonevent->y - y) / (double)(buttonevent->x - x));
      degree = 270 + (rad * (180.0 / PI));
    }
  }
  
  //Filter out jumping through the end points when moving
  if((abs(knob->position - degree) < 30) || (deltacheck == False))
  {
    //Limit on potentiometer range
    if(degree < 30)
      degree = 30;
    else if(degree > 330)
      degree = 330;

    //Only draw when moved
    if(knob->position != degree)
    {
      knob->position = degree;
      
      //Draw the new position
      Opera6KnobDraw(knob);

      //Check if there is an action on this knob
      //!!!!!! For handling actions function is needed here !!!!!!!!
    }
  }
  
  
}

void Opera6KnobDown(MouseEvent *event)
{
  tagOpera6Knob *knob = event->data;
  
  //Starting with moving so draw a new position without delta checking
  Opera6KnobDrawPosition(event, False);

  //Set the pointer for handling the moving
  knob->mouse.move = Opera6KnobMove;
}

void Opera6KnobUp(MouseEvent *event)
{
  tagOpera6Knob *knob = event->data;
  
  //Starting with moving so draw a new position with delta checking to limit falling through the ends
  Opera6KnobDrawPosition(event, True);

  //Set the pointer for handling the moving
  knob->mouse.move = NULL;
}

void Opera6KnobMove(MouseEvent *event)
{
  tagOpera6Knob *knob = event->data;
  
  //Move the indicator to the new position with delta checking to limit falling through the ends
  Opera6KnobDrawPosition(event, True);
}
