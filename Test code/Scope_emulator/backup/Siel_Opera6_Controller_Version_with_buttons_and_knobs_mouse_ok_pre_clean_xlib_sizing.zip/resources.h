#ifndef RESOURCES_H
#define RESOURCES_H

#include "opera6button.h"


//Colors used in the project
#define TextColor               "#F5F9FC"   //For the texts on the panel
#define LogoColor               "#D7E3F1"   //For the texts on the panel
#define PanelLineColor          0xF5F9FC    //For some lines on the panel
#define PanelBlackColor         0x000000    //For lines around the separate parts
#define PanelMetalColor         0x414244    //Background color of the panel and the plastic sides
#define PanelPlanesColor        0xA8CDF7    //Planes and stripes in the control section
#define PanelDividerColor       0xD7E3F1    //Program section separation stripes
#define KnobLightCapColor       0xA8ABB0
#define KnobLightBodyColor      0xB3B5B9
#define KnobLightLineColor      0x8F9398
#define KnobLightIndicatorColor 0x414244
#define KnobDarkCapColor        0x414244
#define KnobDarkBodyColor       0x525356
#define KnobDarkLineColor       0x000000
#define KnobDarkIndicatorColor  0xF5F9FC
#define ButtonCutoutColor       0x000000
#define ButtonLineColor         0x727376
#define ButtonDarkBodyColor     0x414244    //Panel dark button
#define ButtonLightBodyColor    0xA8ABB0    //Light grey button
#define LedBorderColor          0x731A20    //One pixel wide border around the led
#define LedOnColor              0xF82809    //Body color of the led when on
#define LedOffColor             0x591419    //Body color of the led when off

//All the texts on the panel
const tagPlaceText texts[] =
{
  //Text, xpos, ypos, fontid, colorid, align
  //All header texts with 20pt font
  { "MODULATIONS",       408,  98, 0, 0, ALIGN_TEXT_CENTER },
  { "L.F.O.",           1005,  98, 0, 0, ALIGN_TEXT_CENTER },
  { "NOISE",            1365,  98, 0, 0, ALIGN_TEXT_CENTER },
  { "D.C.O.",           1665,  98, 0, 0, ALIGN_TEXT_CENTER },
  { "V.C.F.",           2023,  98, 0, 0, ALIGN_TEXT_CENTER },
  { "DYNAMIC A.D.S.R.", 2373,  98, 0, 0, ALIGN_TEXT_CENTER },
  { "MASTERS",          2848,  98, 0, 0, ALIGN_TEXT_CENTER },
  //All sub header texts with 14pt font
  { "INTERFACES",       2848, 278, 1, 0, ALIGN_TEXT_CENTER },
  { "DETUNE",           1842, 262, 1, 0, ALIGN_TEXT_CENTER },
  { "I-II",              736, 131, 1, 0, ALIGN_TEXT_CENTER },
  { "III",              1202, 131, 1, 0, ALIGN_TEXT_CENTER },
  { "A",                1450, 131, 1, 0, ALIGN_TEXT_CENTER },
  { "B",                1800, 131, 1, 0, ALIGN_TEXT_CENTER },
  //All interface texts with 12pt font
  { "PITCH",             270, 375, 2, 0, ALIGN_TEXT_CENTER },
  { "DEPTH",             360, 375, 2, 0, ALIGN_TEXT_CENTER },
  { "PITCH",             470, 180, 2, 0, ALIGN_TEXT_RIGHT  },
  { "DEPTH",             470, 330, 2, 0, ALIGN_TEXT_RIGHT  },
  { "DCO-A",             539, 137, 2, 0, ALIGN_TEXT_CENTER },
  { "DCO-B",             539, 225, 2, 0, ALIGN_TEXT_CENTER },
  { "LFO I-II",          539, 287, 2, 0, ALIGN_TEXT_CENTER },
  { "LFO III",           539, 375, 2, 0, ALIGN_TEXT_CENTER },

  { "DEPTH",             766, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "SPEED",             881, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "PITCH",             991, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "DCO-A",            1049, 156, 2, 0, ALIGN_TEXT_LEFT   },
  { "DCO-B",            1049, 206, 2, 0, ALIGN_TEXT_LEFT   },
  { "RATE",             1123, 181, 2, 0, ALIGN_TEXT_LEFT   },

  { "DEPTH",             766, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "SPEED",             881, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "PITCH",             991, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "DCO-A",            1049, 306, 2, 0, ALIGN_TEXT_LEFT   },
  { "DCO-B",            1049, 356, 2, 0, ALIGN_TEXT_LEFT   },
  { "RATE",             1123, 331, 2, 0, ALIGN_TEXT_LEFT   },
  { "WAVES",            1234, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "VCF",              1234, 376, 2, 0, ALIGN_TEXT_CENTER },

  { "VOLUME",           1366, 226, 2, 0, ALIGN_TEXT_CENTER },

  { "PW",               1483, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "FOOTAGE",          1590, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "16'",              1648, 156, 2, 0, ALIGN_TEXT_LEFT   },
  { "8'",               1648, 181, 2, 0, ALIGN_TEXT_LEFT   },
  { "4'",               1648, 206, 2, 0, ALIGN_TEXT_LEFT   },
  { "WAVES",            1708, 226, 2, 0, ALIGN_TEXT_CENTER },

  { "HALF",             1366, 373, 2, 0, ALIGN_TEXT_CENTER },
  { "VOLUME",           1366, 387, 2, 0, ALIGN_TEXT_CENTER },
  { "PW",               1483, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "FOOTAGE",          1590, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "16'",              1648, 306, 2, 0, ALIGN_TEXT_LEFT   },
  { "8'",               1648, 331, 2, 0, ALIGN_TEXT_LEFT   },
  { "4'",               1648, 356, 2, 0, ALIGN_TEXT_LEFT   },
  { "WAVES",            1708, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "COARSE",           1841, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "FINE",             1841, 376, 2, 0, ALIGN_TEXT_CENTER },

  { "CUTOFF",           1966, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "RESONANCE",        2081, 226, 2, 0, ALIGN_TEXT_CENTER },
  
  { "KEYBOARD",         1966, 373, 2, 0, ALIGN_TEXT_CENTER },
  { "TRACKING",         1966, 387, 2, 0, ALIGN_TEXT_CENTER },
  { "ADSR",             2081, 373, 2, 0, ALIGN_TEXT_CENTER },
  { "AMOUNT",           2081, 387, 2, 0, ALIGN_TEXT_CENTER },

  { "ATTACK",           2205, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "DECAY",            2317, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "SUSTAIN",          2429, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "RELEASE",          2541, 226, 2, 0, ALIGN_TEXT_CENTER },

  { "ADSR",             2205, 373, 2, 0, ALIGN_TEXT_CENTER },
  { "DESTINATIONS",     2205, 387, 2, 0, ALIGN_TEXT_CENTER },
  { "VCF",              2259, 306, 2, 0, ALIGN_TEXT_LEFT   },
  { "VCA",              2259, 356, 2, 0, ALIGN_TEXT_LEFT   },

  { "DYNAMICS",         2429, 373, 2, 0, ALIGN_TEXT_CENTER },
  { "DESTINATIONS",     2429, 387, 2, 0, ALIGN_TEXT_CENTER },
  { "ADSR LEVEL",       2481, 306, 2, 0, ALIGN_TEXT_LEFT   },
  { "ATTACK TIME",      2481, 356, 2, 0, ALIGN_TEXT_LEFT   },

  { "VOLUME",           2791, 226, 2, 0, ALIGN_TEXT_CENTER },
  { "TUNE",             2906, 226, 2, 0, ALIGN_TEXT_CENTER },
  
  { "MODE",             2791, 376, 2, 0, ALIGN_TEXT_CENTER },
  { "INT.",             2878, 306, 2, 0, ALIGN_TEXT_RIGHT  },
  { "EXT.",             2878, 356, 2, 0, ALIGN_TEXT_RIGHT  },
  { "FROM",             2906, 306, 2, 0, ALIGN_TEXT_LEFT   },
  { "TO",               2906, 356, 2, 0, ALIGN_TEXT_LEFT   },
  { "VERIFY",           2906, 331, 2, 0, ALIGN_TEXT_LEFT   },
  { "MIDI",             2878, 381, 2, 0, ALIGN_TEXT_RIGHT  },
  { "TAPE",             2904, 381, 2, 0, ALIGN_TEXT_LEFT   },

  //The name of the device  
  { "OPERA 6",          2744, 540, 3, 1, ALIGN_TEXT_LEFT   },
};

tagOpera6Knob knobs[] =
{
  //        Mouserange set here to make a linked list. Search for object under mouse pointer needs to be done from last to first based on previous pointer
  //  xc,            previous, left, right, top, bottom, move, down,   up,  out,   xpos, ypos,                    type,          capcolor,          bodycolor,          linecolor,          indicatorcolor,    markercolor, position
  { NULL, {              NULL,    0,     0,   0,      0, NULL, NULL, NULL, NULL },  745,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[0].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },  860,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[1].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },  745,  301,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[2].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },  860,  301,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[3].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 1345,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[4].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 1462,  151,            KNOB_TYPE_PW,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[5].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 1462,  301,            KNOB_TYPE_PW,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[6].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 1820,  151, KNOB_TYPE_DETUNE_COARSE,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[7].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 1820,  301,   KNOB_TYPE_DETUNE_FINE,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[8].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 1945,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {   &knobs[9].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2060,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[10].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2060,  301,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[11].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2184,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[12].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2296,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[13].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2408,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[14].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2520,  151,          KNOB_TYPE_DOTS,  KnobDarkCapColor,  KnobDarkBodyColor,  KnobDarkLineColor,  KnobDarkIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[15].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2770,  151,          KNOB_TYPE_DOTS, KnobLightCapColor, KnobLightBodyColor, KnobLightLineColor, KnobLightIndicatorColor, PanelLineColor,        0 },
  { NULL, {  &knobs[16].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL }, 2885,  151,          KNOB_TYPE_DOTS, KnobLightCapColor, KnobLightBodyColor, KnobLightLineColor, KnobLightIndicatorColor, PanelLineColor,        0 }
};

//All the buttons on the front panel
tagOpera6Button buttons[] = 
{
  //        Mouserange set here to make a linked list. Search for object under mouse pointer needs to be done from last to first based on previous pointer
  //  xc,               previous, left, right, top, bottom, move, down,   up, ledstate, xpos, ypos,   led,            bodycolor,       linecolor,       cutoutcolor, ledoffcolor, ledoncolor,   lededgecolor, state
  { NULL,   {   &knobs[17].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0,  475,  142, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[0].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0,  475,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[1].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0,  971,  142, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[2].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0,  971,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[3].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1214,  142, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[4].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1214,  292,  True,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[5].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1342,  292,  True,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[6].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1570,  142, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[7].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1688,  142, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[8].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1570,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   {  &buttons[9].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1688,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   { &buttons[10].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 1940,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   { &buttons[11].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 2180,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   { &buttons[12].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 2403,  292, False,  ButtonDarkBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 },
  { NULL,   { &buttons[13].mouse,    0,     0,   0,      0, NULL, NULL, NULL, NULL },      0, 2766,  292, False, ButtonLightBodyColor, ButtonLineColor, ButtonCutoutColor, LedOffColor, LedOnColor, LedBorderColor,     0 }
};

//All the leds on the front panel
tagOpera6Led leds[] =
{
  //  xc, state, xpos, ypos, diameter,    offcolor,    oncolor,      edgecolor, x, y, d
  { NULL,     1,  531,  142,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0,  531,  192,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     1,  531,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0,  531,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1027,  142,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1027,  192,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1101,  167,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1027,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1027,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1101,  317,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     1, 1270,  142,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1270,  192,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     1, 1626,  142,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1626,  167,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1626,  192,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1746,  142,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1746,  192,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     1, 1626,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1626,  317,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1626,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1746,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 1746,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 2237,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 2237,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 2459,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 2459,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 2884,  292,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
  { NULL,     0, 2884,  342,       15, LedOffColor, LedOnColor, LedBorderColor, 0, 0, 0 },
};

//Set pointer to last mouse range for scanning
MouseRange *mouseranges = &buttons[14].mouse;

#endif /* RESOURCES_H */

