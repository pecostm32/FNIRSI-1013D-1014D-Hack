
//Use software manager to install mscore for microsoft fonts like Arial

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xlibfunctions.h"
#include "mousehandling.h"
#include "opera6knob.h"
#include "opera6button.h"
#include "opera6led.h"

#include "resources.h"  //All the panel resources are defined in this file. Needs to be the last include file


int DrawFrontPanel(tagXlibContext *xc);

int DrawTriangleWave(tagXlibContext *xc, int xpos, int ypos, int width, int heigth, int color);
int DrawSawtoothWave(tagXlibContext *xc, int xpos, int ypos, int width, int height, int color);
int DrawSquareWave(tagXlibContext *xc, int xpos, int ypos, int width, int height, int color);


//Need to get screen size and determine a suitable width and height based on design being 3200 x 1200 pixels
//Scaling needs to be done in the code itself. Not like in html5 canvas where it is part of the system

//Fonts need to be scaled also!!!!!!

//Scaling needs to be made on some fixed possibilities.
//Design is 3200 x 1200 which is bigger than most monitors. (unless one has 4K monitor)

//Problem in scaling is round of errors, so the design needs to be made with the least possible errors.

//Mostly text will be placed wrong, so might be an idea to do all text placement from the front panel draw function and
//not as legends with the knobs, buttons and leds. Might be easier too.



//Possible error handling needs to be build in

#define DESIGN_WIDTH       3200
#define DESIGN_HEIGHT      1200


#define CalcCoord(c) BORDER_SIZE + (c * xc->scaler)




int main(int argc,char **argv)
{
	Display *display = XOpenDisplay(NULL);
	int screen_num = DefaultScreen(display);
	Window root = RootWindow(display, screen_num);
	Window win = XCreateSimpleWindow(display, root, 0, 0, DESIGN_WIDTH + BORDER_SIZE_2, DESIGN_HEIGHT + BORDER_SIZE_2, 2, BlackPixel(display, screen_num), WhitePixel(display, screen_num));

	XMapWindow(display, win);
  
  //For mouse handling only button press and release are needed in combination with motion which is used for controlling the knobs
	XSelectInput(display, win, ExposureMask | KeyPressMask | ButtonPressMask | ButtonReleaseMask | PointerMotionMask );
  
	GC gc = XCreateGC(display, win, 0, NULL);
  
  
  unsigned int width;	           //width and height for the new window.
  unsigned int height;
  
  unsigned int x,y;
  
  Atom WM_DELETE_WINDOW = XInternAtom(display, "WM_DELETE_WINDOW", False); 
  XSetWMProtocols(display, win, &WM_DELETE_WINDOW, 1);  
  
	XEvent event;
  XWindowAttributes wattrib;

  double fsize;
  
  int rflag = 1;


  tagXlibContext xc;

  int numsizes;  
  XRRScreenSize *scrsize;
  
  scrsize = XRRSizes(display, screen_num, &numsizes);
  

  //Update the window to get the correct size info
//	XNextEvent(display, &event);

  //Get the size of the window to be able to determine the scaler
//  XGetWindowAttributes(display, win, &wattrib);
  
  //For calculations take of a border of 5 pixels for each side
//  width  = (wattrib.width - BORDER_SIZE_2) * 0.95;
//  height = wattrib.height - BORDER_SIZE_2;
  
  width  = (scrsize->width - BORDER_SIZE_2) * 0.95;
  height = scrsize->height - BORDER_SIZE_2;
  
  
   
  xc.scaler = (float)width / (float)DESIGN_WIDTH;

  if((1200 * xc.scaler) > height)
    xc.scaler = (float)height / (float)1200;

  
//Deze is voor testen op volle grote  
//  xc.scaler = 1.0;

  
  width = (DESIGN_WIDTH * xc.scaler) + BORDER_SIZE_2;
  height = (DESIGN_HEIGHT * xc.scaler) + BORDER_SIZE_2;
  
//  x = (wattrib.width - width) / 2;

  x = (scrsize->width - width) / 2;
  y = (scrsize->height - height) / 3;
  
//  XMoveResizeWindow(display, win, x, wattrib.y, width, height);
  
  XMoveResizeWindow(display, win, x, y, width, height);
  
  xc.screen_num = screen_num;
  xc.root = root;
  xc.win = win;
  xc.display = display;
  xc.gc = gc;
  
  xc.visual = DefaultVisual(display, screen_num);
  xc.cmap  = DefaultColormap(display, screen_num);

    
    
  fsize = 20 * xc.scaler;
  xc.font[0] = XftFontOpen(display, screen_num, XFT_FAMILY, XftTypeString, "Arial", XFT_WEIGHT, XftTypeInteger, XFT_WEIGHT_BOLD, XFT_SIZE, XftTypeDouble, fsize, XFT_ANTIALIAS, XftTypeBool, True, NULL);

  fsize = 14 * xc.scaler;
  xc.font[1] = XftFontOpen(display, screen_num, XFT_FAMILY, XftTypeString, "Arial", XFT_WEIGHT, XftTypeInteger, XFT_WEIGHT_BOLD, XFT_SIZE, XftTypeDouble, fsize, XFT_ANTIALIAS, XftTypeBool, True, NULL);

  fsize = 12 * xc.scaler;
  xc.font[2] = XftFontOpen(display, screen_num, XFT_FAMILY, XftTypeString, "Arial Narrow", XFT_WEIGHT, XftTypeInteger, XFT_WEIGHT_BOLD, XFT_SIZE, XftTypeDouble, fsize, XFT_ANTIALIAS, XftTypeBool, True, NULL);

  fsize = 62 * xc.scaler;
  xc.font[3] = XftFontOpen(display, screen_num, XFT_FAMILY, XftTypeString, "Arial Narrow", XFT_WEIGHT, XftTypeInteger, XFT_WEIGHT_BOLD, XFT_SIZE, XftTypeDouble, fsize, XFT_ANTIALIAS, XftTypeBool, True, NULL);
  
  rflag = XftColorAllocName(display, xc.visual, xc.cmap, TextColor, &xc.color[0]);

  rflag = XftColorAllocName(display, xc.visual, xc.cmap, LogoColor, &xc.color[1]);
  
  xc.draw = XftDrawCreate(display, win, xc.visual, xc.cmap);
  
//Non blocking checking for X events  
//  mask = KeyPressMask | KeyReleaseMask | ButtonPressMask | ButtonReleaseMask;
//  while (XCheckWindowEvent(xDisplay, xWin, mask, &evt) || XCheckTypedWindowEvent(xDisplay, xWin, ClientMessage, &evt))
//  {
       // Handle event
//  }

 //Tweede mogelijkheid is XPending checken  
          // Handle XEvents and flush the input 
//        while(XPending(dis))
//            XNextEvent(dis, &ev);

  
  
  
  //Keep running until window is destroyed
	while(rflag)
	{
		XNextEvent(display, &event);
		switch(event.type)
		{
			case Expose:
        //Setup the screen
        DrawFrontPanel(&xc);
				break;
        
			case KeyPress:
				if(event.xkey.keycode == XKeysymToKeycode(display,XK_Escape))
				{
					rflag = 0;
				}
        break;
        
      case ButtonPress:
        //Call mouse handling function down()
        MouseDown(&event);
        break;
        
      case ButtonRelease:
        //Call mouse handling function up()
        MouseUp(mouseranges, &event);
        break;
        
      case MotionNotify:
        //Call mouse handling function move()
        MouseMove(mouseranges, &event);
        break;
        
      case ClientMessage:
        if(event.xclient.data.l[0] == WM_DELETE_WINDOW)
        {
					rflag = 0;
        }
        break;
		}
	}
  
  
  
  XftColorFree(display, xc.visual, xc.cmap, &xc.color[0]);
  XftColorFree(display, xc.visual, xc.cmap, &xc.color[1]);
  XftDrawDestroy(xc.draw);
  
  XDestroyWindow(display, win);
	XCloseDisplay(display);
	return 0;
}


int DrawFrontPanel(tagXlibContext *xc)
{
  int i,n,y;
  XPoint points[6];
  
  //Draw the metal front panel base and the section underneath the keyboard
  DrawFillRect(xc, 101, 20, 3000, 1160, PanelMetalColor, PanelBlackColor, 1);
  
  //Draw the plastic side panels
  DrawFillRoundedRect(xc, 0,    0, 12, 100, 1200, PanelMetalColor, PanelBlackColor, 1);
  DrawFillRoundedRect(xc, 3100, 0, 12, 100, 1200, PanelMetalColor, PanelBlackColor, 1);
  
  //Draw the plastic panels besides the keyboard
  DrawFillRoundedRect(xc, 102, 721, 8, 20, 458, PanelMetalColor, PanelBlackColor, 1);
  DrawFillRoundedRect(xc, 3079, 721, 8, 20, 458, PanelMetalColor, PanelBlackColor, 1);
  
  //Draw the separator above the keyboard
  DrawLine(xc, 101, 720, 3099, 720, PanelBlackColor, 1);
  
  //Draw the program section borders
  FillRect(xc, 115, 452, 2970, 10, PanelDividerColor);
  FillRect(xc, 115, 663, 2970, 10, PanelDividerColor);
  
  //Panel stripes and planes
  for(i=0,y=71;i<8;i++,y+=45)
  {
    FillRect(xc,  115, y, 110, 5, PanelPlanesColor);
    FillRect(xc,  590, y, 110, 5, PanelPlanesColor);
    FillRect(xc, 2610, y, 110, 5, PanelPlanesColor);
    FillRect(xc, 2975, y, 110, 5, PanelPlanesColor);
  }
  
  //Modulations
  FillRect(xc, 240,  71, 335,  35, PanelPlanesColor);
  FillRect(xc, 240, 111, 335, 280, PanelPlanesColor);
  
  //Setup points for LFO III
  points[0].x = CalcCoord(715);
  points[0].y = CalcCoord(258);
  points[1].x = CalcCoord(1185);
  points[1].y = CalcCoord(258);
  points[2].x = CalcCoord(1185);
  points[2].y = CalcCoord(111);
  points[3].x = CalcCoord(1294);
  points[3].y = CalcCoord(111);
  points[4].x = CalcCoord(1294);
  points[4].y = CalcCoord(390);
  points[5].x = CalcCoord(715);
  points[5].y = CalcCoord(390);
  
  //LFO
  FillRect(xc, 715,  71, 580,  35, PanelPlanesColor);
  FillRect(xc, 715, 111, 455, 133, PanelPlanesColor);
  FillPolygon(xc, points, 6, PanelPlanesColor);

  //Noise
  FillRect(xc, 1310,  71, 110,  35, PanelPlanesColor);
  FillRect(xc, 1310, 111, 110, 133, PanelPlanesColor);

  //Setup points for DCO B
  points[0].x = CalcCoord(1310);
  points[0].y = CalcCoord(258);
  points[1].x = CalcCoord(1785);
  points[1].y = CalcCoord(258);
  points[2].x = CalcCoord(1785);
  points[2].y = CalcCoord(111);
  points[3].x = CalcCoord(1894);
  points[3].y = CalcCoord(111);
  points[4].x = CalcCoord(1894);
  points[4].y = CalcCoord(390);
  points[5].x = CalcCoord(1310);
  points[5].y = CalcCoord(390);
  
  //DCO
  FillRect(xc, 1435,  71, 460,  35, PanelPlanesColor);
  FillRect(xc, 1435, 111, 335, 133, PanelPlanesColor);
  FillPolygon(xc, points, 6, PanelPlanesColor);

  //VCF
  FillRect(xc, 1910,  71, 225,  35, PanelPlanesColor);
  FillRect(xc, 1910, 111, 225, 133, PanelPlanesColor);
  FillRect(xc, 1910, 258, 225, 133, PanelPlanesColor);

  //Dynamic ADSR
  FillRect(xc, 2150,  71, 445,  35, PanelPlanesColor);
  FillRect(xc, 2150, 111, 445, 133, PanelPlanesColor);
  FillRect(xc, 2150, 258, 445, 133, PanelPlanesColor);

  //Master
  FillRect(xc, 2735,  71, 225,  35, PanelPlanesColor);
  FillRect(xc, 2735, 111, 225, 133, PanelPlanesColor);
  FillRect(xc, 2735, 258, 225, 133, PanelPlanesColor);

  //Borders around midi and tape text in interfaces
  DrawRect(xc, 2845, 366, 37, 18, PanelLineColor, 2);
  DrawRect(xc, 2900, 366, 43, 18, PanelLineColor, 2);
  
  //Setup points for detune pointer below coarse
  points[0].x = CalcCoord(1841);
  points[0].y = CalcCoord(233);
  points[1].x = CalcCoord(1851);
  points[1].y = CalcCoord(243);
  points[2].x = CalcCoord(1831);
  points[2].y = CalcCoord(243);
  points[3].x = CalcCoord(1841);
  points[3].y = CalcCoord(233);
  
  //Draw detune pointer below coarse
  DrawLines(xc, points, 4, PanelLineColor, 2);

  //Setup points for detune pointer above fine
  points[0].x = CalcCoord(1841);
  points[0].y = CalcCoord(277);
  points[1].x = CalcCoord(1851);
  points[1].y = CalcCoord(267);
  points[2].x = CalcCoord(1831);
  points[2].y = CalcCoord(267);
  points[3].x = CalcCoord(1841);
  points[3].y = CalcCoord(277);
  
  //Draw detune pointer above file
  DrawLines(xc, points, 4, PanelLineColor, 2);

  //Setup points for lines below from led
  points[0].x = CalcCoord(2892);
  points[0].y = CalcCoord(311);
  points[1].x = CalcCoord(2892);
  points[1].y = CalcCoord(323);
  points[2].x = CalcCoord(2902);
  points[2].y = CalcCoord(323);
  
  //Draw lines below from led
  DrawLines(xc, points, 3, PanelLineColor, 2);

  //Setup points for lines above to led
  points[0].x = CalcCoord(2892);
  points[0].y = CalcCoord(338);
  points[1].x = CalcCoord(2892);
  points[1].y = CalcCoord(327);
  points[2].x = CalcCoord(2902);
  points[2].y = CalcCoord(327);
  
  //Draw lines above to led
  DrawLines(xc, points, 3, PanelLineColor, 2);
  
  //Legends for LFO III wave leds
  DrawTriangleWave(xc, 1269, 162, 17, 10, PanelLineColor);
  DrawSquareWave(xc, 1269, 178, 17, 10, PanelLineColor);

  //DCO A and B wave led legends  
  DrawSawtoothWave(xc, 1745, 162, 17, 10, PanelLineColor);
  DrawSquareWave(xc, 1745, 178, 17, 10, PanelLineColor);
  DrawSawtoothWave(xc, 1745, 312, 17, 10, PanelLineColor);
  DrawSquareWave(xc, 1745, 328, 17, 10, PanelLineColor);
  
  //Place all the texts
  n = sizeof(texts) / sizeof(tagPlaceText);
  for(i=0;i<n;i++)
    PlaceText(xc, texts[i].x, texts[i].y, texts[i].text, texts[i].fontid, texts[i].colorid, texts[i].align);

  //Setup all the knobs
  n = sizeof(knobs) / sizeof(tagOpera6Knob);
  for(i=0;i<n;i++)
    Opera6KnobSetup(xc, &knobs[i]);
  
  //Setup all the buttons
  n = sizeof(buttons) / sizeof(tagOpera6Button);
  for(i=0;i<n;i++)
    Opera6ButtonSetup(xc, &buttons[i]);
  
  //Setup all the leds
  n = sizeof(leds) / sizeof(tagOpera6Led);
  for(i=0;i<n;i++)
    Opera6LedSetup(xc, &leds[i]);
  
  return 0;
}

int DrawTriangleWave(tagXlibContext *xc, int xpos, int ypos, int width, int height, int color)
{
  XPoint points[3];
  int x1 = CalcCoord(xpos);
  int x2 = CalcCoord((xpos + (width / 2)));
  int x3 = CalcCoord((xpos + width));
  int y1 = CalcCoord((ypos + height));
  int y2 = CalcCoord(ypos);

  //Setup points for the triangle
  points[0].x = x1;
  points[0].y = y1;
  points[1].x = x2;
  points[1].y = y2;
  points[2].x = x3;
  points[2].y = y1;

  //Draw the lines
  DrawLines(xc, points, 3, color, 2);
  
  return 0;
}

int DrawSawtoothWave(tagXlibContext *xc, int xpos, int ypos, int width, int height, int color)
{
  XPoint points[3];
  int dt = width / 4;
  int x1 = CalcCoord((xpos + dt));
  int x2 = CalcCoord((xpos + width - dt));
  int y1 = CalcCoord((ypos + height));
  int y2 = CalcCoord(ypos);

  //Setup points for the triangle
  points[0].x = x1;
  points[0].y = y1;
  points[1].x = x2;
  points[1].y = y2;
  points[2].x = x2;
  points[2].y = y1;

  //Draw the lines
  DrawLines(xc, points, 3, color, 2);
  
  return 0;
}

int DrawSquareWave(tagXlibContext *xc, int xpos, int ypos, int width, int height, int color)
{
  XPoint points[6];
  int dt = width / 4;
  int x1 = CalcCoord(xpos);
  int x2 = CalcCoord((xpos + dt));
  int x3 = CalcCoord((xpos + width - dt));
  int x4 = CalcCoord((xpos + width));
  int y1 = CalcCoord((ypos + height));
  int y2 = CalcCoord(ypos);

  //Setup points for the square wave
  points[0].x = x1;
  points[0].y = y1;
  points[1].x = x2;
  points[1].y = y1;
  points[2].x = x2;
  points[2].y = y2;
  points[3].x = x3;
  points[3].y = y2;
  points[4].x = x3;
  points[4].y = y1;
  points[5].x = x4;
  points[5].y = y1;

  //Draw the lines
  DrawLines(xc, points, 6, color, 2);
  
  return 0;
}

