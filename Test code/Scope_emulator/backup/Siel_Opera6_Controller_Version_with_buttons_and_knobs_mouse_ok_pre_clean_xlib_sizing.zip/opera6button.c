//-----------------------------------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------------------------------

#include "opera6button.h"

#define CalcCoord(c)  BORDER_SIZE + ((c) * xc->scaler)
#define CalcCoordX(x) BORDER_SIZE + ((button->xpos + (x)) * xc->scaler)
#define CalcCoordY(y) BORDER_SIZE + ((button->ypos + (y)) * xc->scaler)

void Opera6ButtonSetup(tagXlibContext *xc, tagOpera6Button *button)
{
  MouseRange  *mouse = &button->mouse;

  button->xc = xc;
  
  //Fill in the mouserange struct to be able to use the button via the mouse
  mouse->left   = CalcCoordX(0);
  mouse->right  = CalcCoordX(47);
  mouse->top    = CalcCoordY(0);
  mouse->bottom = CalcCoordY(65);
  
  mouse->data = button;
  mouse->move = NULL;
  mouse->down = Opera6ButtonDown;
  mouse->up   = Opera6ButtonUp;
  
  Opera6ButtonDraw(button);
}


void Opera6ButtonDown(MouseEvent *event)
{
  tagOpera6Button *button = event->data;
  
  button->state = 1;
  Opera6ButtonDraw(button);
}

void Opera6ButtonUp(MouseEvent *event)
{
  tagOpera6Button *button = event->data;

  button->state = 0;
  Opera6ButtonDraw(button);
  
  
      //Check if there is an action on this knob
      //!!!!!! For handling actions function is needed here !!!!!!!!
  
}


void Opera6ButtonDraw(tagOpera6Button *button)
{
  tagXlibContext *xc = button->xc;
  XSegment lines[2];
  XPoint points[10];

  int x = CalcCoord(button->xpos);
  int y = CalcCoord(button->ypos);
  int w = 47 * xc->scaler;
  int h = 65 * xc->scaler;
  
  //Setup the line width to one pixel for the cutout
  XSetLineAttributes(xc->display, xc->gc, 1, LineSolid, CapButt, JoinMiter);

  //First fill the rectangle with the fill color
  XSetForeground(xc->display, xc->gc, button->bodycolor);
  XFillRectangle(xc->display, xc->win, xc->gc, x, y, w, h);
  
  //Then draw the outer line with the line color
  XSetForeground(xc->display, xc->gc, button->cutoutcolor);
  XDrawRectangle(xc->display, xc->win, xc->gc, x, y, w, h);

  //Setup the line width to two pixels for the lines on the button
  XSetLineAttributes(xc->display, xc->gc, 2, LineSolid, CapButt, JoinMiter);
  XSetForeground(xc->display, xc->gc, button->linecolor);
  
  //Setup the points based on the current state
  if(button->state == 0)
  {
    //Setup the points for drawing the up state when button->state is cleared
    points[0].x = CalcCoordX(6);
    points[0].y = CalcCoordY(1);
    points[1].x = CalcCoordX(3);
    points[1].y = CalcCoordY(5);
    points[2].x = CalcCoordX(2);
    points[2].y = CalcCoordY(7);
    points[3].x = CalcCoordX(4);
    points[3].y = CalcCoordY(12);
    points[4].x = CalcCoordX(5);
    points[4].y = CalcCoordY(16);
    points[5].x = CalcCoordX(5);
    points[5].y = CalcCoordY(49);
    points[6].x = CalcCoordX(4);
    points[6].y = CalcCoordY(53);
    points[7].x = CalcCoordX(2);
    points[7].y = CalcCoordY(58);
    points[8].x = CalcCoordX(3);
    points[8].y = CalcCoordY(60);
    points[9].x = CalcCoordX(6);
    points[9].y = CalcCoordY(64);

    XDrawLines(xc->display, xc->win, xc->gc, points, 10, CoordModeOrigin);

    points[0].x = CalcCoordX(44);
    points[0].y = CalcCoordY(1);
    points[1].x = CalcCoordX(41);
    points[1].y = CalcCoordY(5);
    points[2].x = CalcCoordX(40);
    points[2].y = CalcCoordY(7);
    points[3].x = CalcCoordX(42);
    points[3].y = CalcCoordY(12);
    points[4].x = CalcCoordX(43);
    points[4].y = CalcCoordY(16);
    points[5].x = CalcCoordX(43);
    points[5].y = CalcCoordY(49);
    points[6].x = CalcCoordX(42);
    points[6].y = CalcCoordY(53);
    points[7].x = CalcCoordX(40);
    points[7].y = CalcCoordY(58);
    points[8].x = CalcCoordX(41);
    points[8].y = CalcCoordY(60);
    points[9].x = CalcCoordX(44);
    points[9].y = CalcCoordY(64);

    XDrawLines(xc->display, xc->win, xc->gc, points, 10, CoordModeOrigin);
   
    lines[0].x1 = CalcCoordX(2);
    lines[0].y1 = CalcCoordY(7);
    lines[0].x2 = CalcCoordX(40);
    lines[0].y2 = CalcCoordY(7);

    lines[1].x1 = CalcCoordX(2);
    lines[1].y1 = CalcCoordY(58);
    lines[1].x2 = CalcCoordX(40);
    lines[1].y2 = CalcCoordY(58);
    
    XDrawSegments(xc->display, xc->win, xc->gc, lines, 2);
  }
  else
  {
    //Setup the points for drawing the up state when button->state is set
    points[0].x = CalcCoordX(6);
    points[0].y = CalcCoordY(1);
    points[1].x = CalcCoordX(4);
    points[1].y = CalcCoordY(4);
    points[2].x = CalcCoordX(6);
    points[2].y = CalcCoordY(6);
    points[3].x = CalcCoordX(8);
    points[3].y = CalcCoordY(12);
    points[4].x = CalcCoordX(8);
    points[4].y = CalcCoordY(53);
    points[5].x = CalcCoordX(6);
    points[5].y = CalcCoordY(59);
    points[6].x = CalcCoordX(4);
    points[6].y = CalcCoordY(61);
    points[7].x = CalcCoordX(6);
    points[7].y = CalcCoordY(64);

    XDrawLines(xc->display, xc->win, xc->gc, points, 8, CoordModeOrigin);
    
    points[0].x = CalcCoordX(44);
    points[0].y = CalcCoordY(1);
    points[1].x = CalcCoordX(42);
    points[1].y = CalcCoordY(4);
    points[2].x = CalcCoordX(44);
    points[2].y = CalcCoordY(6);
    points[3].x = CalcCoordX(46);
    points[3].y = CalcCoordY(12);
    points[4].x = CalcCoordX(46);
    points[4].y = CalcCoordY(53);
    points[5].x = CalcCoordX(44);
    points[5].y = CalcCoordY(59);
    points[6].x = CalcCoordX(42);
    points[6].y = CalcCoordY(61);
    points[7].x = CalcCoordX(44);
    points[7].y = CalcCoordY(64);
    
    XDrawLines(xc->display, xc->win, xc->gc, points, 8, CoordModeOrigin);

    lines[0].x1 = CalcCoordX(4);
    lines[0].y1 = CalcCoordY(4);
    lines[0].x2 = CalcCoordX(42);
    lines[0].y2 = CalcCoordY(4);

    lines[1].x1 = CalcCoordX(4);
    lines[1].y1 = CalcCoordY(61);
    lines[1].x2 = CalcCoordX(42);
    lines[1].y2 = CalcCoordY(61);
    
    XDrawSegments(xc->display, xc->win, xc->gc, lines, 2);
  }
 
  //Check if a led needs to be drawn
  if(button->led)
  {
    //led is 13 pixels
    int d = 13 *xc->scaler;
    
    //Set position of the led
    x = CalcCoordX(16);
    y = CalcCoordY(13);
    
    //Set the body color of the led based on the state
    if(button->ledstate)
      XSetForeground(xc->display, xc->gc, button->ledoncolor);
    else
      XSetForeground(xc->display, xc->gc, button->ledoffcolor);

    XFillArc(xc->display, xc->win, xc->gc, x, y, d, d, Angle0, Angle360);

    XSetLineAttributes(xc->display, xc->gc, 1, LineSolid, CapButt, JoinMiter);
    XSetForeground(xc->display, xc->gc, button->lededgecolor);
    XDrawArc(xc->display, xc->win, xc->gc, x, y, d, d, Angle0, Angle360);
  }
}
