#ifndef BUTTON_H
#define BUTTON_H

#include "xlibfunctions.h"
#include "mousehandling.h"

//Position is given as top left of the bounding box the button is in
//The size of the button is fixed

typedef struct
{
  tagXlibContext *xc;               //Xlib context for drawing
  MouseRange      mouse;            //Mouse object for this button. Is used for setting the bounding box and to connect the handlers
  int             ledstate;         //State of the led. Either on or off
  int             xpos;             //Un scaled x position
  int             ypos;             //Un scaled y position
  Bool            led;              //Flag to signal led needs to be drawn
  int             bodycolor;        //Color of the body
  int             linecolor;        //Color of the lines
  int             cutoutcolor;      //Color of the panel cutout
  int             ledoffcolor;      //Color of the led when off
  int             ledoncolor;       //Color of the led when on
  int             lededgecolor;     //Color of the ring around the led
  int             state;            //State of the button. Either up or down
} tagOpera6Button;


void Opera6ButtonSetup(tagXlibContext *xc, tagOpera6Button *button);
void Opera6ButtonDraw(tagOpera6Button *button);
void Opera6ButtonSetLedState(tagOpera6Button *button, int state);

void Opera6ButtonDown(MouseEvent *event);
void Opera6ButtonUp(MouseEvent *event);

#endif /* BUTTON_H */

