#ifndef LED_H
#define LED_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xlibfunctions.h"

#define LED_LEGEND_TYPE_TEXT_ABOVE_CENTER_ALIGNED            0
#define LED_LEGEND_TYPE_TEXT_BELOW_CENTER_ALIGNED           11

#define LED_LEGEND_TYPE_TEXT_RIGHT_LEFT_ALIGNED              2

#define LED_LEGEND_TYPE_TRIANGLE_WAVE                        4
#define LED_LEGEND_TYPE_RISING_SAWTOOTH_WAVE                 6
#define LED_LEGEND_TYPE_SQUARE_WAVE                          7



#define LED_LEGEND_TYPE_TEXT_ABOVE_RIGHT_ALIGNED             1
#define LED_LEGEND_TYPE_MULTIPLE_TEXT_CENTER_ALIGNED         3
#define LED_LEGEND_TYPE_FALLING_SAWTOOTH_WAVE                5
#define LED_LEGEND_TYPE_PULSE_WAVE                           8



typedef struct
{
  tagXlibContext *xc;               //Xlib context for drawing
  int             state;            //State of the led. Either on or off
  int             x;                //x position of the center of the led
  int             y;                //y position of the center of the led
  int             size;             //Size of the led
  int             offcolor;         //Color of the led when off
  int             oncolor;          //Color of the led when on
  int             edgecolor;        //Color of the ring around the led
  int             fontid;           //Font used for the legend text
  int             fontcolorid;      //Color of the legend text
  int             legendtype;       //Type of the legend
  char           *legendtext;       //Text for the legend
} tagLed;


void LedSetup(tagXlibContext *xc, int state, int xpos, int ypos, int size, int offcolor, int oncolor, int edgecolor, int fontid, int fontcolorid, int legendtype, char *legendtext, tagLed *led);
void LedDraw(tagLed *led);
void LedSetState(tagLed *led, int state);

#endif /* LED_H */

