/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "led.h"

void LedSetup(tagXlibContext *xc, int state, int xpos, int ypos, int size, int offcolor, int oncolor, int edgecolor, int fontid, int fontcolorid, int legendtype, char *legendtext, tagLed *led)
{
  XPoint points[6];
  int x,y;
  int r = size / 2;
  
  led->xc = xc;
  
  if(state)
    led->state = 1;
  else
    led->state = 0;
  
  led->x = BORDER_SIZE + (xpos * xc->scaler);
  led->y = BORDER_SIZE + (ypos * xc->scaler);
  
  led->size = size * xc->scaler;
  
  led->offcolor = offcolor;
  led->oncolor = oncolor;
  led->edgecolor = edgecolor;
  
  led->fontid = fontid;
  led->fontcolorid = fontcolorid;
  
  led->legendtype = legendtype;
  led->legendtext = legendtext;
  
  switch(legendtype)
  {
    case LED_LEGEND_TYPE_TEXT_ABOVE_CENTER_ALIGNED:
      x = xpos + r;
      y = ypos - r;
      PlaceText(xc, x, y, legendtext, fontid, fontcolorid, ALIGN_TEXT_CENTER);
      break;
      
    case LED_LEGEND_TYPE_TEXT_BELOW_CENTER_ALIGNED:
      x = xpos + r;
      y = ypos + size + xc->font[fontid]->height;
      PlaceText(xc, x, y, legendtext, fontid, fontcolorid, ALIGN_TEXT_CENTER);
      break;
      
    case LED_LEGEND_TYPE_TEXT_RIGHT_LEFT_ALIGNED:
      x = xpos + size + r;
      y = ypos - r + xc->font[fontid]->height;
      PlaceText(xc, x, y, legendtext, fontid, fontcolorid, ALIGN_TEXT_LEFT);
      break;
      
    case LED_LEGEND_TYPE_TRIANGLE_WAVE:
      //Setup points for lines below the led
      points[0].x = BORDER_SIZE +  (xpos * xc->scaler);
      points[0].y = BORDER_SIZE + ((ypos + size + 8 + r) * xc->scaler);
      points[1].x = BORDER_SIZE + ((xpos + r) * xc->scaler);
      points[1].y = BORDER_SIZE + ((ypos + size + 6) * xc->scaler);
      points[2].x = BORDER_SIZE + ((xpos + size) * xc->scaler);
      points[2].y = BORDER_SIZE + ((ypos + size + 8 + r) * xc->scaler);

      //Draw lines below the led
      DrawLines(xc, points, 3, xc->color[fontcolorid].pixel, 2);
      break;
      
    case LED_LEGEND_TYPE_RISING_SAWTOOTH_WAVE:
      //Setup points for lines below the led
      points[0].x = BORDER_SIZE + ((xpos + 3) * xc->scaler);
      points[0].y = BORDER_SIZE + ((ypos + size + 8 + r) * xc->scaler);
      points[1].x = BORDER_SIZE + ((xpos + size - 3) * xc->scaler);
      points[1].y = BORDER_SIZE + ((ypos + size + 6) * xc->scaler);
      points[2].x = BORDER_SIZE + ((xpos + size - 3) * xc->scaler);
      points[2].y = BORDER_SIZE + ((ypos + size + 9 + r) * xc->scaler);

      //Draw lines below the led
      DrawLines(xc, points, 3, xc->color[fontcolorid].pixel, 2);
      break;
      
    case LED_LEGEND_TYPE_SQUARE_WAVE:
      //Setup points for lines above the led
      points[0].x = BORDER_SIZE +  (xpos * xc->scaler);
      points[0].y = BORDER_SIZE + ((ypos - 6) * xc->scaler);
      points[1].x = BORDER_SIZE + ((xpos + 4) * xc->scaler);
      points[1].y = BORDER_SIZE + ((ypos - 6) * xc->scaler);
      points[2].x = BORDER_SIZE + ((xpos + 4) * xc->scaler);
      points[2].y = BORDER_SIZE + ((ypos - 8 - r) * xc->scaler);
      points[3].x = BORDER_SIZE + ((xpos + size - 4) * xc->scaler);
      points[3].y = BORDER_SIZE + ((ypos -  8 - r) * xc->scaler);
      points[4].x = BORDER_SIZE + ((xpos + size - 4) * xc->scaler);
      points[4].y = BORDER_SIZE + ((ypos - 6) * xc->scaler);
      points[5].x = BORDER_SIZE + ((xpos + size) * xc->scaler);
      points[5].y = BORDER_SIZE + ((ypos - 6) * xc->scaler);

      //Draw lines above the led
      DrawLines(xc, points, 6, xc->color[fontcolorid].pixel, 2);
      break;
  }
  
  LedDraw(led);
}

void LedDraw(tagLed *led)
{
  tagXlibContext *xc = led->xc;
  
  //Set the body color of the led based on the state
  if(led->state)
    XSetForeground(xc->display, xc->gc, led->oncolor);
  else
    XSetForeground(xc->display, xc->gc, led->offcolor);

  XFillArc(xc->display, xc->win, xc->gc, led->x, led->y, led->size, led->size, Angle0, Angle360);
  
  XSetLineAttributes(xc->display, xc->gc, 1, LineSolid, CapButt, JoinMiter);
  XSetForeground(xc->display, xc->gc, led->edgecolor);
  XDrawArc(xc->display, xc->win, xc->gc, led->x, led->y, led->size, led->size, Angle0, Angle360);
}

void LedSetState(tagLed *led, int state)
{
  if(state)
    led->state = 1;
  else
    led->state = 0;
    
  LedDraw(led);
}
